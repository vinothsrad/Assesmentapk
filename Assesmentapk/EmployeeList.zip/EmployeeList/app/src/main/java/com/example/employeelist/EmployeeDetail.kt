package com.example.employeelist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EmployeeDetail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_employee_detail)

    }
}