package com.example.employeelist

data class Geo(
    val lat: String,
    val lng: String
)