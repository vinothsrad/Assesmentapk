package com.example.employeelist

class UserDetails : ArrayList<UserDetailsItem>()