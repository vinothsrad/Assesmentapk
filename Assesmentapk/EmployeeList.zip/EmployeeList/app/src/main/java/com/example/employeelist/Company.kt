package com.example.employeelist

data class Company(
    val bs: String,
    val catchPhrase: String,
    val name: String
)